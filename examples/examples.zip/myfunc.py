def print_msg(msg):
    print("msg: ", msg, "~")